# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## ⚠️ CRITICAL: Work Smart - Use Memory & Tools!

**ALWAYS use these tools to save 70% token usage:**

### 1. Load Context from Memory (500 tokens vs 20,000!)
```bash
# First thing in ANY session - retrieve stored context
mcp__syncore__memory_query("project_context")
mcp__syncore__memory_query("implementation_plan")
mcp__syncore__memory_query("phase_X_status")
```

### 2. Use Ripgrep Instead of Reading Full Files
```bash
# Instead of Read tool on entire files (5,000 tokens):
rg "struct.*Embeddings" --type rust src/vector.rs -A 20  # 100 tokens
rg "impl.*Candle" --type rust -c src/                     # Instant counts
rg "CREATE TABLE" src/db.rs                               # Find schemas
```

### 3. Store Knowledge After Every Session
```bash
# End of session - preserve context for next time
mcp__syncore__memory_store("current_task", "Task 1.2 - Testing embeddings")
mcp__syncore__memory_store("blockers", "None")
mcp__syncore__memory_store("next_steps", "Implement code graph")
```

### 4. Use TaskMaster for Structured Plans
```bash
# Create tasks from PRD instead of ad-hoc planning
mcp__task-master-ai__parse_prd(projectRoot, input, numTasks)
```

**Token Savings**: 240K → 73.5K tokens (70% reduction!)

---

## Project Overview

**SynCore** is an AI-native Model Context Protocol (MCP) server that provides intelligent memory, task management, vector search, and sequential reasoning capabilities. It bridges the gap between AI agents and persistent, structured knowledge storage.

The codebase is written in Rust and consists of:
- An MCP server implementation using the `rmcp` library
- Multi-modal storage: key-value memory (SQLite + Sled cache), task management (SQLite), vector search (HNSW)
- Cognitive components: sequential reasoning loops, parser analysis, and Candle GGUF LLM integration
- Multiple transport modes: stdio (MCP protocol) and TCP (legacy MessagePack-RPC)

## Build and Test Commands

### Main workspace
```bash
# Build the main SynCore binary (TCP server mode)
cd syncore
cargo build --release

# Build the MCP stdio server (for MCP clients like Claude Desktop)
cargo build --release --bin syncore_mcp_stdio

# Run all tests
cargo test

# Run specific test
cargo test <test_name>

# Run tests with output
cargo test -- --nocapture

# Run benchmarks
cargo bench
```

### Starting the server

**MCP stdio mode** (for Claude Desktop, Cline, etc.):
```bash
# The MCP server runs via stdio transport
cd syncore
cargo run --bin syncore_mcp_stdio
```

**TCP server mode** (legacy):
```bash
cd syncore
SYNCORE_MODE=mcp TRANSPORT=http cargo run
```

Environment variables:
- `SYNCORE_MODE`: `mcp` (default) or `msgpack` (legacy)
- `TRANSPORT`: `stdio` (MCP), `http` (TCP)
- `DB_PATH`: Database file path (default: `syncore.db`)
- `SOCKET_PATH`: TCP address (default: `127.0.0.1:8080`)
- `METRICS_ADDR`: Metrics server address (default: `127.0.0.1:9090`)

## Architecture

### Core Components (by LOC)

**Storage Layer**:
- `src/memory.rs` (133 LOC): Hybrid SQLite (persistent) + Sled (fast cache) for key-value storage
- `src/tasks.rs` (367 LOC): SQLite-backed task management with parent-child hierarchy and graph edges (`task_links`)
- `src/vector.rs` (515 LOC): **Linear scan** vector search with custom semantic embeddings (NOT HNSW despite dependency)

**MCP Integration**:
- `src/mcp_server.rs` (572 LOC): rmcp-based MCP server with `#[tool]` macro handlers
- `src/mcp.rs` (322 LOC): Legacy JSON-RPC request handling
- `src/router.rs` (226 LOC): Routes tool calls to appropriate handlers, maintains `SynCoreState`

**Cognitive/AI Components**:
- `src/sequential.rs` (816 LOC): Sequential reasoning loops with Candle GGUF LLM (think → decide → reflect cycle)
- `src/cognitive.rs` (351 LOC): Cognitive database operations for storing reasoning steps
- `src/intellitask.rs` (761 LOC): AI-powered PRD parsing, task generation, prioritization, and subtask expansion
- `src/parser.rs` (1003 LOC): Tree-sitter based code analysis for 6 languages (Rust, JS, Python, JSON, TOML, Bash)
- `src/llm/candle_cache.rs` (315 LOC): Candle GGUF cache module for local LLM inference

**Infrastructure**:
- `src/circuit_breaker.rs` (378 LOC): Circuit breaker pattern to prevent runaway LLM calls
- `src/logger.rs` (248 LOC): Markdown-formatted structured logging for reasoning steps
- `src/metrics.rs` (257 LOC): Prometheus-compatible metrics endpoint
- `src/meta_cognition.rs` (337 LOC): Meta-cognitive reflection and self-monitoring
- `src/autonomy.rs` (304 LOC): Autonomous agent behaviors (heartbeat, nudges)

### Transport Modes

1. **stdio (MCP)**: Main mode for MCP clients. Uses `rmcp` library with `transport::stdio`
2. **TCP (Legacy)**: MessagePack-RPC over TCP for backward compatibility

### Data Flow

```
MCP Client (Claude Desktop)
    ↓ (stdio)
syncore_mcp_stdio binary
    ↓
MCPServerHandler (rmcp)
    ↓
Tool Router → [memory, tasks, vector, sequential, parser, intellitask]
    ↓
Storage Layer (SQLite, Sled, HNSW)
```

### Tool Categories

All tools are exposed via MCP using the `#[tool]` macro on async handler functions:

- **Memory**: `memory_store`, `memory_query` - key-value storage with dual-layer (SQLite + Sled)
- **Tasks**: `task_create`, `task_list`, `task_update`, `task_get` - task management with graph relationships
- **Vector**: `vector_insert`, `vector_search` - semantic search (384-dim embeddings)
- **Sequential**: `sequential_cycle` - multi-step reasoning loops with Candle GGUF LLM integration
- **Parser**: `parser_analyze`, `parser_search` - tree-sitter based code analysis (Rust, JS, Python, JSON, TOML, Bash)
- **IntelliTask**: `intellitask_generate`, `intellitask_prioritize`, `intellitask_next`, `intellitask_subtasks` - AI-powered task breakdown and planning
- **Logs**: `logs_tail` - retrieve structured cognitive logs

## Key Implementation Details

### Database Schema
All schemas are created/migrated via `src/db.rs::ensure_schema()`. Uses WAL mode for SQLite.

**Memory table**:
```sql
CREATE TABLE memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    k TEXT NOT NULL,
    v TEXT NOT NULL,
    ts INTEGER NOT NULL
);
CREATE UNIQUE INDEX idx_memory_k ON memory(k);
```

**Tasks table** (with graph relationships):
```sql
CREATE TABLE tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',
    priority INTEGER NOT NULL DEFAULT 3,
    parent_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE INDEX idx_tasks_status_prio ON tasks(status, priority, id);
CREATE INDEX idx_tasks_parent ON tasks(parent_id);

-- Task graph edges
CREATE TABLE task_links (
    src_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    dst_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,  -- 'depends_on' or 'relates_to'
    PRIMARY KEY (src_id, dst_id, kind)
);
```

**Cognitive steps** (reasoning history):
```sql
CREATE TABLE steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
    state TEXT NOT NULL,  -- Think|Decide|Act|Observe|Reflect
    content TEXT NOT NULL,
    meta_json TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL
);
CREATE INDEX idx_steps_task_state_time ON steps(task_id, state, created_at DESC);
```

### Vector Embeddings
- Uses custom semantic word vector embeddings via `RealEmbeddings` (384 dimensions by default)
- **Linear scan search** with cosine similarity (O(n) complexity)
- Parallel search available via `search_parallel()` using Rayon
- TF-IDF weighted averaging for sentence embeddings
- Hardcoded semantic vocabulary (~100 words) + hash-based fallback for unknown words
- **Note**: `VectorMeta` includes HNSW parameters (m=32, ef_construction=200) but HNSW is not implemented

### Sequential Reasoning
The sequential reasoning loop (`sequential.rs`) implements a think-decide-reflect cycle:
1. **Think**: LLM analyzes context and current state
2. **Decide**: LLM chooses action based on thought
3. **Act**: Execute action (file ops, task ops, vector ops)
4. **Reflect**: LLM evaluates outcome and decides to continue or stop

Uses circuit breaker pattern to prevent runaway LLM calls.

### IntelliTask System
AI-powered task management that uses Candle GGUF for:
- **PRD parsing**: Generate task breakdown from product requirements
- **Prioritization**: Smart dependency-aware task ordering
- **Subtask expansion**: Break down complex tasks into actionable steps
- **Next task suggestion**: Recommend what to work on next

### Tree-sitter Parser
Supports code analysis for: Rust, JavaScript, Python, JSON, TOML, Bash
- `parser_analyze`: Extract structure (functions, classes, imports)
- `parser_search`: Ripgrep-based code search with context

## Testing Strategy

- **Unit tests**: Inline `#[cfg(test)]` modules in each file
- **Integration tests**: `tests/` directory for cross-module testing
- **E2E tests**: `tests/e2e/` for full workflow validation
- **Key test files**:
  - `tests/mcp_crud_tests.rs`: MCP protocol compliance
  - `tests/router_wiring_test.rs`: Tool routing verification
  - `tests/e2e/task_lifecycle.rs`: End-to-end task workflows

## Important Patterns

### Error Handling
Use `anyhow::Result` for all fallible operations. Avoid `.unwrap()` except in tests or after explicit checks.

### Concurrency
- `Arc<Mutex<T>>` for shared mutable state (SQLite connections, vector stores)
- Tokio async runtime for I/O operations
- Rayon for CPU-bound parallel operations (vector search, embeddings)

### MCP Tool Registration
All tools must be:
1. Defined as structs with `serde::Deserialize` + `schemars::JsonSchema`
2. Registered in `create_tool_router()` in `mcp_server.rs`
3. Implemented as `#[tool_handler]` async functions

### Database Access
Always acquire locks in consistent order to prevent deadlocks:
1. Memory
2. Tasks
3. Vector store

## Development Workflow

### Smart Workflow (Use This!)

1. **Start session - Load context from memory**:
   ```bash
   mcp__syncore__memory_query("project_context")
   mcp__syncore__memory_query("current_task")
   mcp__syncore__memory_query("phase_X_status")
   ```

2. **Verify current state with ripgrep** (not Read tool!):
   ```bash
   rg "target_function" --type rust src/ -B 3 -A 10
   rg "struct.*YourStruct" --type rust -c src/
   ```

3. **Make focused changes** to specific files/lines identified by ripgrep

4. **Run tests** to verify: `cargo test`

5. **Store progress in memory**:
   ```bash
   mcp__syncore__memory_store("task_X_status", "completed")
   mcp__syncore__memory_store("files_modified", "src/vector.rs:10-270")
   mcp__syncore__memory_store("next_task", "Task Y description")
   ```

6. **Use ripgrep for verification**:
   ```bash
   rg "impl Embeddings for HuggingFace" --type rust src/ -c
   # Output: 1 (success!)
   ```

### Traditional Workflow (Avoid - Uses 3x Tokens!)

1. ~~Read full files~~ → Use ripgrep instead
2. ~~Re-read context each session~~ → Load from memory
3. ~~Ad-hoc planning~~ → Use TaskMaster PRD parsing
4. Make changes to source files in `src/`
5. Run tests: `cargo test`
6. Format code: `cargo fmt`
7. Check for issues: `cargo clippy`
8. Build release: `cargo build --release`
9. Test MCP integration: Run with stdio mode and connect via Claude Desktop

## Configuration Files

- `syncore/Cargo.toml`: Dependencies and build configuration
- `syncore/mcp.toml`: MCP server metadata (name, version, capabilities)
- `claude-desktop-config.json`: Example Claude Desktop integration config
- `mcp-config.json`: Alternative MCP client configuration

## Logging and Debugging

Logs are written to:
- `logs/`: Markdown-formatted structured logs (cognitive steps)
- `server.log`: Main server activity
- Stdout/stderr: MCP protocol messages (in stdio mode)

Enable detailed logging:
```bash
RUST_LOG=debug cargo run --bin syncore_mcp_stdio
```

## Memory Keys Available

**Always check these keys at session start**:

- `project_context` - High-level overview (7866 LOC, architecture)
- `improvement_priorities` - What needs to be done (embeddings, Candle GGUF, code graph)
- `architecture_insights` - Storage details (SQLite, Sled, no Neo4j/HNSW)
- `implementation_plan` - Structured task breakdown
- `token_analysis` - How to save 70% tokens
- `analysis_embeddings` - Current state of vector embeddings
- `analysis_candle` - Current state of Candle GGUF integration
- `analysis_code_graph` - Code graph mapping plans
- `phase_1_status` - Real embeddings implementation status
- `phase_2_status` - Candle GGUF implementation status
- `phase_3_status` - Code graph implementation status
- `current_task` - What you should be working on NOW
- `blockers` - Any issues preventing progress
- `next_steps` - What to do after current task

**Query pattern**:
```bash
mcp__syncore__memory_query("current_task")
# Returns: "Task 1.2 - Testing HuggingFace embeddings"
```

## Known Limitations

- Vector embeddings use simple semantic word vectors (not production-grade transformers) - **FIX IN PROGRESS**
- Sequential reasoning requires local GGUF model files
- IntelliTask features depend on Candle GGUF model availability
- No distributed mode (single-node only)
- Sled cache may corrupt on unclean shutdown (auto-recovery implemented)

**See IMPROVEMENT_ANALYSIS.md for planned fixes**

## Dependencies Note

Key dependencies and their roles (verified via `cargo tree`):
- `rmcp` (v0.8.5): MCP protocol implementation with stdio transport
- `tokio` (v1.x): Async runtime for MCP server
- `rusqlite` (v0.31): SQLite database with bundled SQLite, WAL mode
- `sled` (v0.34): Embedded B-tree cache (memory layer)
- `hnsw_rs` (v0.3.2): In `Cargo.toml` but **NOT USED** - linear search instead
- `tree-sitter` (v0.20) + language parsers: Multi-language code analysis
- `fastembed` (v0.4): Embedding model utilities (TF-IDF semantic vectors)
- `petgraph` (v0.6): In `Cargo.toml` but **NOT USED** - SQLite tables for graph
- `reqwest` (v0.12): HTTP client for web operations
- `rayon` (v1.8): Parallel processing for vector search and embeddings

**Note**: Several dependencies (`hnsw_rs`, `petgraph`) are included for future use but current implementation uses simpler alternatives (linear vector search, SQLite graph tables).

## Future Architecture

The repository contains extensive research documents (`research/`) describing plans for a full multi-modal database called SynapseDB. Current SynCore implementation is Phase 1 - the MCP server foundation. Future phases will integrate:
- Graph storage and traversal
- Columnar analytics
- Advanced RAG with evidence provenance
- Distributed replication
- Mini-model reasoning engine

For context on the broader vision, see: `research/architecture/SynapseDB_Master_Summary.md`
