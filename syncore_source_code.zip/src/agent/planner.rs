//! Planning Engine - PHASE 4 Core Component
//!
//! Deterministic planning engine that creates and refines multi-step plans
//! using existing memory, vector, and graph APIs. Enforces circuit breaker
//! patterns and uses only existing infrastructure.

use crate::agent::{current_timestamp_ms, ApreError, ApreResult};
use crate::llm::prompt_hash::{hash_prompt, PromptHashConfig};
use crate::memory::Memory;
use crate::raggraph::{HopGraphTransformer, RagGraphConfig, RagGraphResult};
use crate::vector::VectorStore;
use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use uuid::Uuid;

/// Plan node status representing execution state
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum PlanNodeStatus {
    /// Node is ready to be executed (dependencies satisfied)
    Ready,
    /// Node is currently being executed
    InProgress,
    /// Node completed successfully
    Completed,
    /// Node failed and needs attention
    Failed,
    /// Node is blocked by dependencies
    Pending,
    /// Node was skipped (not needed)
    Skipped,
}

/// Plan node representing a single action in the plan
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlanNode {
    /// Unique identifier for this plan node
    pub id: String,

    /// Task description
    pub task: String,

    /// Node priority (higher = more important)
    pub priority: i32,

    /// Current execution status
    pub status: PlanNodeStatus,

    /// Dependencies (IDs of nodes that must complete first)
    pub dependencies: Vec<String>,

    /// Estimated complexity (1-10)
    pub complexity: i32,

    /// Creation timestamp
    pub created_at: i64,

    /// Completion timestamp (if applicable)
    pub completed_at: Option<i64>,

    /// Error message (if failed)
    pub error_message: Option<String>,

    /// Result/output from execution (if any)
    pub result: Option<String>,

    /// Metadata for graph retrieval
    pub metadata: HashMap<String, String>,
}

impl PlanNode {
    /// Create a new plan node
    pub fn new(task: String, priority: i32) -> Self {
        let id = format!("plan_node_{}", Uuid::new_v4());
        Self {
            id,
            task,
            priority,
            status: PlanNodeStatus::Pending,
            dependencies: Vec::new(),
            complexity: 5, // Default medium complexity
            created_at: current_timestamp_ms(),
            completed_at: None,
            error_message: None,
            result: None,
            metadata: HashMap::new(),
        }
    }

    /// Check if node is ready for execution
    pub fn is_ready(&self) -> bool {
        self.status == PlanNodeStatus::Ready
            || (self.status == PlanNodeStatus::Pending && self.dependencies.is_empty())
    }

    /// Check if node is completed successfully
    pub fn is_completed(&self) -> bool {
        self.status == PlanNodeStatus::Completed
    }

    /// Check if node has failed
    pub fn is_failed(&self) -> bool {
        self.status == PlanNodeStatus::Failed
    }
}

/// Plan tree containing all nodes and their relationships
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlanTree {
    /// Unique plan identifier
    pub id: String,

    /// Overall goal of this plan
    pub goal: String,

    /// All plan nodes
    pub nodes: Vec<PlanNode>,

    /// Plan creation timestamp
    pub created_at: i64,

    /// Plan modification timestamp
    pub updated_at: i64,

    /// Plan metadata
    pub metadata: HashMap<String, String>,
}

impl PlanTree {
    /// Create a new plan tree
    pub fn new(goal: String) -> Self {
        let id = format!("plan_{}", Uuid::new_v4());
        let now = current_timestamp_ms();
        Self {
            id,
            goal,
            nodes: Vec::new(),
            created_at: now,
            updated_at: now,
            metadata: HashMap::new(),
        }
    }

    /// Add a node to the plan
    pub fn add_node(&mut self, mut node: PlanNode) {
        self.updated_at = current_timestamp_ms();
        self.nodes.push(node);
    }

    /// Get node by ID
    pub fn get_node(&self, node_id: &str) -> Option<&PlanNode> {
        self.nodes.iter().find(|node| node.id == node_id)
    }

    /// Get nodes by status
    pub fn get_nodes_by_status(&self, status: PlanNodeStatus) -> Vec<&PlanNode> {
        self.nodes.iter().filter(|node| node.status == status).collect()
    }

    /// Get ready nodes (those with satisfied dependencies)
    pub fn get_ready_nodes(&self) -> Vec<&PlanNode> {
        let completed_ids: HashSet<_> =
            self.nodes.iter().filter(|node| node.is_completed()).map(|node| &node.id).collect();

        self.nodes
            .iter()
            .filter(|node| {
                node.status == PlanNodeStatus::Pending
                    && node.dependencies.iter().all(|dep| completed_ids.contains(dep))
            })
            .collect()
    }

    /// Check if plan is complete (all nodes completed or skipped)
    pub fn is_complete(&self) -> bool {
        self.nodes.iter().all(|node| node.is_completed() || node.status == PlanNodeStatus::Skipped)
    }
}

/// Deterministic Planning Engine
///
/// Uses existing memory, vector, and graph APIs to create and refine plans.
/// Enforces circuit breaker patterns and maintains deterministic behavior.
#[derive(Debug)]
pub struct PlanningEngine {
    /// Memory service for plan persistence and context
    memory: Arc<Memory>,

    /// Vector store for semantic similarity search
    vector_store: Arc<std::sync::Mutex<VectorStore>>,

    /// HopGraph for multi-hop reasoning and semantic retrieval
    hop_graph: HopGraphTransformer,

    /// Deterministic hasher for plan consistency
    hash_config: PromptHashConfig,

    /// Circuit breaker for failure protection
    failure_count: std::sync::atomic::AtomicU32,
    max_failures: u32,
}

impl PlanningEngine {
    /// Create a new planning engine
    pub fn new(
        memory: Arc<Memory>,
        vector_store: Arc<std::sync::Mutex<VectorStore>>,
        hop_graph: HopGraphTransformer,
    ) -> Self {
        Self {
            memory,
            vector_store,
            hop_graph,
            hash_config: PromptHashConfig::default(),
            failure_count: std::sync::atomic::AtomicU32::new(0),
            max_failures: 5,
        }
    }

    /// Generate initial plan from goal and constraints
    pub async fn generate_initial_plan(
        &mut self,
        goal: &str,
        constraints: &[String],
    ) -> ApreResult<PlanTree> {
        // Circuit breaker check
        if self.failure_count.load(std::sync::atomic::Ordering::Relaxed) >= self.max_failures {
            return Err(ApreError::CircuitBreakerActivated(
                "Planning engine circuit breaker activated".to_string(),
            ));
        }

        // Create deterministic plan ID
        let plan_hash = hash_prompt(goal);
        let mut plan = PlanTree::new(goal.to_string());
        plan.metadata.insert("hash".to_string(), plan_hash.to_string());
        plan.metadata.insert("constraints".to_string(), constraints.join(","));

        // Use semantic search to find relevant context
        let context = self.retrieve_semantic_context(goal).await?;

        // Generate plan nodes using existing reasoning patterns
        let nodes = self.generate_plan_nodes(goal, constraints, &context).await?;

        for node in nodes {
            plan.add_node(node);
        }

        // Store plan in memory for persistence
        self.store_plan(&plan).await?;

        // Mark as success
        self.failure_count.store(0, std::sync::atomic::Ordering::Relaxed);

        Ok(plan)
    }

    /// Refine plan after action execution
    pub async fn refine_plan_after_action(
        &mut self,
        plan: &mut PlanTree,
        node_id: &str,
        success: bool,
        result_message: Option<&str>,
        error_message: Option<&str>,
    ) -> ApreResult<PlanTree> {
        // Find and update the node
        let node = plan.nodes.iter_mut().find(|n| n.id == node_id).ok_or_else(|| {
            ApreError::PlanningFailed(format!("Node {} not found in plan", node_id))
        })?;

        // Update node status and metadata
        node.status = if success {
            PlanNodeStatus::Completed
        } else {
            PlanNodeStatus::Failed
        };

        node.completed_at = Some(current_timestamp_ms());

        if let Some(msg) = result_message {
            node.result = Some(msg.to_string());
        }

        if let Some(msg) = error_message {
            node.error_message = Some(msg.to_string());
        }

        // Update dependent nodes status
        self.update_dependent_nodes(plan).await?;

        // Store updated plan
        plan.updated_at = current_timestamp_ms();
        self.store_plan(plan).await?;

        Ok(plan.clone())
    }

    /// Detect deadlocks in the plan
    pub async fn detect_deadlocks(&self, plan: &PlanTree) -> ApreResult<Vec<Vec<String>>> {
        let mut deadlocks = Vec::new();
        let mut visited = HashSet::new();
        let mut rec_stack = HashSet::new();

        // Build dependency graph
        let mut graph: HashMap<String, Vec<String>> = HashMap::new();
        for node in &plan.nodes {
            graph.insert(node.id.clone(), node.dependencies.clone());
        }

        // Detect cycles using DFS
        for node in &plan.nodes {
            if !visited.contains(&node.id) {
                if let Some(cycle) =
                    self.detect_cycle(&node.id, &graph, &mut visited, &mut rec_stack)
                {
                    deadlocks.push(cycle);
                }
            }
        }

        Ok(deadlocks)
    }

    /// Get next action to execute
    pub async fn next_action<'a>(
        &mut self,
        plan: &'a mut PlanTree,
    ) -> ApreResult<Option<&'a PlanNode>> {
        // Get ready nodes sorted by priority (highest first)
        let mut ready_nodes = plan.get_ready_nodes();
        ready_nodes.sort_by(|a, b| b.priority.cmp(&a.priority));

        if ready_nodes.is_empty() {
            return Ok(None);
        }

        // Update first ready node to InProgress
        let node_id = ready_nodes[0].id.clone();
        let node =
            plan.nodes.iter_mut().find(|n| n.id == node_id).expect("Ready node should exist");

        node.status = PlanNodeStatus::InProgress;

        Ok(Some(node))
    }

    /// Retrieve semantic context using existing vector and graph APIs
    async fn retrieve_semantic_context(&self, goal: &str) -> ApreResult<Vec<String>> {
        let mut context = Vec::new();

        // Use vector store for semantic search
        match self.vector_store.lock().unwrap().search(goal, 10, crate::vector::SearchScope::Global)
        {
            Ok(results) => {
                for result in results {
                    context.push(result.text);
                }
            }
            Err(_) => {
                // Fallback: use memory service
                match self.memory.query(goal) {
                    Ok(Some(entry)) => {
                        context.push(entry);
                    }
                    Ok(None) | Err(_) => {
                        // No context available, continue with empty context
                    }
                }
            }
        }

        // Use HopGraph for multi-hop reasoning if configured
        if !context.is_empty() {
            // Create seed nodes from context (simplified approach)
            let seed_nodes: Vec<i64> = (0..context.len() as i64).collect();

            if let Ok(rag_result) = self.hop_graph.multi_hop_reasoning(&seed_nodes) {
                // Add reasoning path to context
                context.extend(rag_result.reasoning_path);
            }
        }

        Ok(context)
    }

    /// Generate plan nodes from goal, constraints, and context
    async fn generate_plan_nodes(
        &self,
        goal: &str,
        constraints: &[String],
        context: &[String],
    ) -> ApreResult<Vec<PlanNode>> {
        let mut nodes = Vec::new();

        // Create root node for the main goal
        let mut root_node = PlanNode::new(goal.to_string(), 100);
        root_node.status = PlanNodeStatus::Ready;

        // Add context to root node metadata
        root_node.metadata.insert("has_context".to_string(), (!context.is_empty()).to_string());

        nodes.push(root_node);

        // Generate subtasks based on goal analysis
        let subtasks = self.analyze_goal_into_subtasks(goal, constraints, context).await?;

        for (i, subtask) in subtasks.iter().enumerate() {
            let mut node = PlanNode::new(subtask.clone(), 80 - i as i32 * 5);

            // Add dependency on root (all subtasks depend on main goal acceptance)
            if let Some(root) = nodes.first() {
                node.dependencies.push(root.id.clone());
            }

            // Add constraint information
            if !constraints.is_empty() {
                node.metadata.insert("constraints".to_string(), constraints.join(","));
            }

            nodes.push(node);
        }

        Ok(nodes)
    }

    /// Analyze goal into subtasks using semantic patterns
    async fn analyze_goal_into_subtasks(
        &self,
        goal: &str,
        _constraints: &[String],
        _context: &[String],
    ) -> ApreResult<Vec<String>> {
        // Simplified subtask generation using pattern matching
        // In production, this would use the LLM or more sophisticated analysis

        let goal_lower = goal.to_lowercase();
        let mut subtasks = Vec::new();

        // Pattern-based subtask generation
        if goal_lower.contains("implement") || goal_lower.contains("build") {
            if goal_lower.contains("authentication") {
                subtasks.push("Design authentication flow".to_string());
                subtasks.push("Implement user registration".to_string());
                subtasks.push("Implement login functionality".to_string());
                subtasks.push("Add password reset".to_string());
            } else if goal_lower.contains("api") {
                subtasks.push("Design API endpoints".to_string());
                subtasks.push("Implement data models".to_string());
                subtasks.push("Create validation logic".to_string());
                subtasks.push("Add error handling".to_string());
            } else if goal_lower.contains("database") {
                subtasks.push("Design database schema".to_string());
                subtasks.push("Create migration scripts".to_string());
                subtasks.push("Implement data access layer".to_string());
            } else {
                subtasks.push("Analyze requirements".to_string());
                subtasks.push("Design solution".to_string());
                subtasks.push("Implement core functionality".to_string());
                subtasks.push("Add tests".to_string());
            }
        } else if goal_lower.contains("test") {
            subtasks.push("Write unit tests".to_string());
            subtasks.push("Write integration tests".to_string());
            subtasks.push("Run test suite".to_string());
            subtasks.push("Fix any failures".to_string());
        } else {
            // Generic task breakdown
            subtasks.push("Understand the requirements".to_string());
            subtasks.push("Break down the problem".to_string());
            subtasks.push("Implement solution".to_string());
            subtasks.push("Verify the result".to_string());
        }

        Ok(subtasks)
    }

    /// Update dependent nodes after action completion
    async fn update_dependent_nodes(&self, plan: &mut PlanTree) -> ApreResult<()> {
        let completed_ids: HashSet<_> = plan
            .nodes
            .iter()
            .filter(|node| node.is_completed())
            .map(|node| node.id.clone())
            .collect();

        // Update pending nodes whose dependencies are satisfied
        for node in plan.nodes.iter_mut() {
            if node.status == PlanNodeStatus::Pending {
                let dependencies_satisfied =
                    node.dependencies.iter().all(|dep| completed_ids.contains(dep));

                if dependencies_satisfied {
                    node.status = PlanNodeStatus::Ready;
                }
            }
        }

        Ok(())
    }

    /// Detect cycle in dependency graph using DFS
    fn detect_cycle(
        &self,
        node_id: &str,
        graph: &HashMap<String, Vec<String>>,
        visited: &mut HashSet<String>,
        rec_stack: &mut HashSet<String>,
    ) -> Option<Vec<String>> {
        visited.insert(node_id.to_string());
        rec_stack.insert(node_id.to_string());

        if let Some(dependencies) = graph.get(node_id) {
            for dep in dependencies {
                if !visited.contains(dep) {
                    if let Some(cycle) = self.detect_cycle(dep, graph, visited, rec_stack) {
                        return Some(cycle);
                    }
                } else if rec_stack.contains(dep) {
                    // Found a cycle
                    let mut cycle = vec![dep.clone(), node_id.to_string()];
                    return Some(cycle);
                }
            }
        }

        rec_stack.remove(node_id);
        None
    }

    /// Store plan in memory for persistence
    async fn store_plan(&self, plan: &PlanTree) -> ApreResult<()> {
        let plan_json = serde_json::to_string(plan).map_err(|e| {
            ApreError::MemoryError(anyhow::anyhow!("Failed to serialize plan: {}", e))
        })?;

        let key = format!("plan:{}", plan.id);
        self.memory.store(&key, &plan_json).map_err(|e| ApreError::MemoryError(e))?;

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_plan_node_creation() {
        let node = PlanNode::new("Test task".to_string(), 5);

        assert!(node.id.starts_with("plan_node_"));
        assert_eq!(node.task, "Test task");
        assert_eq!(node.priority, 5);
        assert_eq!(node.status, PlanNodeStatus::Pending);
        assert_eq!(node.complexity, 5);
    }

    #[test]
    fn test_plan_node_status_checks() {
        let mut node = PlanNode::new("Test".to_string(), 1);

        assert!(!node.is_ready());
        assert!(!node.is_completed());
        assert!(!node.is_failed());

        node.status = PlanNodeStatus::Ready;
        assert!(node.is_ready());

        node.status = PlanNodeStatus::Completed;
        assert!(node.is_completed());

        node.status = PlanNodeStatus::Failed;
        assert!(node.is_failed());
    }

    #[test]
    fn test_plan_tree_creation() {
        let plan = PlanTree::new("Test goal".to_string());

        assert!(plan.id.starts_with("plan_"));
        assert_eq!(plan.goal, "Test goal");
        assert!(plan.nodes.is_empty());
        assert!(plan.created_at > 0);
        assert!(plan.updated_at > 0);
    }

    #[test]
    fn test_plan_tree_node_management() {
        let mut plan = PlanTree::new("Test".to_string());
        let node = PlanNode::new("Task 1".to_string(), 1);
        let node_id = node.id.clone();

        plan.add_node(node);

        assert_eq!(plan.nodes.len(), 1);
        assert!(plan.get_node(&node_id).is_some());
        assert_eq!(plan.get_nodes_by_status(PlanNodeStatus::Pending).len(), 1);
    }

    #[test]
    fn test_dependency_resolution() {
        let mut plan = PlanTree::new("Test".to_string());

        // Add root node
        let root = PlanNode::new("Root".to_string(), 10);
        let root_id = root.id.clone();
        plan.add_node(root);

        // Add dependent node
        let mut child = PlanNode::new("Child".to_string(), 5);
        child.dependencies.push(root_id.clone());
        plan.add_node(child);

        // Initially no ready nodes (child has dependency)
        assert_eq!(plan.get_ready_nodes().len(), 0);

        // Complete root
        if let Some(root) = plan.nodes.iter_mut().find(|n| n.id == root_id) {
            root.status = PlanNodeStatus::Completed;
        }

        // Now child should be ready
        assert_eq!(plan.get_ready_nodes().len(), 1);
    }

    #[test]
    fn test_cycle_detection() {
        let memory = Arc::new(create_mock_memory());
        let vector_store = Arc::new(std::sync::Mutex::new(create_mock_vector_store()));
        let hop_graph = HopGraphTransformer::new(create_mock_rag_config());

        let planner = PlanningEngine::new(memory, vector_store, hop_graph);

        let mut plan = PlanTree::new("Test".to_string());

        // Create nodes with circular dependency
        let node1 = PlanNode::new("Node 1".to_string(), 1);
        let node2 = PlanNode::new("Node 2".to_string(), 1);

        let id1 = node1.id.clone();
        let id2 = node2.id.clone();

        plan.add_node(node1);
        plan.add_node(node2);

        // Create circular dependency manually for testing
        if let Some(node1) = plan.nodes.iter_mut().find(|n| n.id == id1) {
            node1.dependencies.push(id2.clone());
        }
        if let Some(node2) = plan.nodes.iter_mut().find(|n| n.id == id2) {
            node2.dependencies.push(id1.clone());
        }

        // This test would need the actual implementation to work
        // For now, we'll just test the structure
        assert_eq!(plan.nodes.len(), 2);
    }

    // Mock helpers for testing
    fn create_mock_memory() -> Memory {
        // This would need a proper mock implementation
        unimplemented!("Mock memory not implemented")
    }

    fn create_mock_vector_store() -> VectorStore {
        // This would need a proper mock implementation
        unimplemented!("Mock vector store not implemented")
    }

    fn create_mock_rag_config() -> RagGraphConfig {
        RagGraphConfig {
            embedding_dim: 384,
            num_hops: 3,
            top_k: 10,
            alpha: 0.7,
            backend_mode: crate::raggraph::RaggraphBackendMode::Mock,
        }
    }
}
